const csv = require('csv-parser');
const fs = require('fs');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const normalEdgeCsvWriter = createCsvWriter({
  path: 'NormalEdeges.csv',
  header: [
    {id: 'node1', title: 'node1'},
    {id: 'node2', title: 'node2'}
  ]
});

const WeightedEdgeCsvWriter = createCsvWriter({
  path: 'WeightedEdeges.csv',
  header: [
    {id: 'node1', title: 'node1'},
    {id: 'node2', title: 'node2'},
    {id: 'weight', title: 'weight'},
  ]
});

var attendenceData = [];
var nodes =  new Set();
var edges = new Map() ;
var graph = {};

fs.createReadStream('volunteer_attendance_data.csv')
  .pipe(csv())
  .on('data', (row) => {
    attendenceData.push(row);
  })
  .on('end', () => {
    console.log('CSV file successfully processed');
    makeNodes();
  });

  function makeNodes(){
    var shiftDictionary = {};
    attendenceData.forEach( shifts => {
      nodes.add(shifts.volunteerName);
      AddVolunteerToShiftDictionary(shifts,shiftDictionary);
    });
    makeBidirectionalGraph(shiftDictionary);
  }

  function makeBidirectionalGraph(shiftDictionary){
    for (var dateTime in shiftDictionary){
      if (shiftDictionary.hasOwnProperty(dateTime)) {           
         // console.log(key, dictionary[key]);
         volunteerNames = shiftDictionary[dateTime];
         for(let i=0 ; i < volunteerNames.length ; i++){
           for (let j = i + 1 ; j < volunteerNames.length ; j++){
             addEdge(volunteerNames,i,j);
           }
         }
      }
    }
    writeOutPutToCsv();
  }

  function writeOutPutToCsv(){
    let normalEdges = [];
    let WeightedEdeges = [];
    for (const [key, value] of edges) {
      let nodeObject = JSON.parse(key);
      normalEdges.push(nodeObject);
      nodeObject['weight'] = value;
      WeightedEdeges.push(nodeObject);
    }

    normalEdgeCsvWriter
    .writeRecords(normalEdges)
    .then(()=> console.log('The CSV file was written successfully'));

    WeightedEdgeCsvWriter
    .writeRecords(WeightedEdeges)
    .then(()=> console.log('The CSV file was written successfully'));
  }

  function addEdge(volunteerNames,i,j){
    let u = volunteerNames[i];
    let v = volunteerNames[j];
    if(u>v){
      [u, v] = [v, u];
    }
    let jsonKey = JSON.stringify({
      node1: u,
      node2: v
    });
    if(edges.has(jsonKey)){
      let weight = edges.get(jsonKey);
      edges.set(jsonKey,weight+1);
    } else {
      edges.set(jsonKey,1);
      addEdgeToGraph(u,v);
    }
  }

  function addEdgeToGraph(u,v){
    if(!graph.hasOwnProperty(u)) { graph[u] = [];}
    if(!graph.hasOwnProperty(v)) { graph[v] = [];}
    graph[u].push(v);
    graph[v].push(u);
  }

  function swap(u,v){
    let temp=u;
    u=v;
    v=temp;
  }


  function AddVolunteerToShiftDictionary(shifts,shiftDictionary){
    var dateTime = shifts.date +'-'+ shifts.shift;
    if(shiftDictionary[dateTime] == null || shiftDictionary[dateTime] == undefined){
      shiftDictionary[dateTime] = [];
    }
    shiftDictionary[dateTime].push(shifts.volunteerName);
  }