Steps to test the code:

1. Install Node.js
2. Open CMD i.e. node js command prompt
3. run "node Solution.js" by going to Solution folder directory.


Used modules
1. csv-parser
2. csv-writer